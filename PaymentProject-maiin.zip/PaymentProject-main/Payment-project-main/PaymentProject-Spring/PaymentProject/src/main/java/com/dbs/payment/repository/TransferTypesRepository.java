package com.dbs.payment.repository;

import org.springframework.data.repository.CrudRepository;

import com.dbs.payment.model.TransferTypes;

public interface TransferTypesRepository extends CrudRepository<TransferTypes, String>{

}
