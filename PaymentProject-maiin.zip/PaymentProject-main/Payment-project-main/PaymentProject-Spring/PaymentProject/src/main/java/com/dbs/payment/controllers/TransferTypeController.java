package com.dbs.payment.controllers;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class TransferTypeController {

}
