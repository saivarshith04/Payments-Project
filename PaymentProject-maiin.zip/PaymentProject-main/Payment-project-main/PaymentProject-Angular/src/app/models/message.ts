export class Message{
    constructor(public messagecode: string, public instruction: string) {

    }
}