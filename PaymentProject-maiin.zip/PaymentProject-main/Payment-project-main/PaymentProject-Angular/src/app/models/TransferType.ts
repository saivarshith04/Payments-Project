export class TransferType {
    constructor(public transfertypecode: string,
        public transfertypedescription: string){
            
        }
}