export class Bank{
    constructor(public bankname: string,
        public bic: string
       ){
    }
}